from django.apps import AppConfig


class MagasinConfig(AppConfig):
    name = 'magasin'
